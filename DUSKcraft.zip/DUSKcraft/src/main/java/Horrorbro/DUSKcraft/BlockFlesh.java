package Horrorbro.DUSKcraft;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockFlesh extends Block {

	protected BlockFlesh(Material material) {
		super(material);
		// TODO Auto-generated constructor stub
	}

}
