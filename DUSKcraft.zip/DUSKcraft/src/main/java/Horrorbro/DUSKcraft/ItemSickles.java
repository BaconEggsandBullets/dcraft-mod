package Horrorbro.DUSKcraft;

import net.minecraft.item.Item;

public class ItemSickles extends Item {

}
