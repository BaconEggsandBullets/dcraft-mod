package Horrorbro.DUSKcraft;

import net.minecraft.item.Item;

public class ItemFlesh extends Item {

}
