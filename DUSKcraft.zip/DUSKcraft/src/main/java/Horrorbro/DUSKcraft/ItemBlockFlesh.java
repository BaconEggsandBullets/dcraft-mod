package Horrorbro.DUSKcraft;

import net.minecraft.item.Item;

public class ItemBlockFlesh extends Item {

}
